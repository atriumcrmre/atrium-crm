/**
 * Keystone AI: a thin proxy to the configured AI provider (Google Gemini or Claude) so the
 * API key stays on the server. The browser runs the tool loop; its tools edit records
 * through /api/sync.
 */
const express = require("express");
const rateLimit = require("express-rate-limit");
const { requireUser } = require("../lib/auth");
const ai = require("../services/ai");

const r = express.Router();
r.use(requireUser);
r.use(rateLimit({ windowMs: 60 * 1000, limit: 30, keyGenerator: (req) => req.user.id, standardHeaders: true, legacyHeaders: false, message: { error: "Keystone is busy. Try again in a minute." } }));

r.post("/ai/messages", express.json({ limit: "1mb" }), async (req, res) => {
  const { system, messages, tools, max_tokens } = req.body || {};
  if (!Array.isArray(messages) || !messages.length) return res.status(400).json({ error: "messages is required" });
  try {
    const out = await ai.complete({
      system: system ? String(system).slice(0, 200000) : undefined,
      messages,
      tools: Array.isArray(tools) ? tools.slice(0, 20) : undefined,
      maxTokens: Math.min(Number(max_tokens) || 1500, 4000),
      userId: req.user.id,
    });
    res.json(out);
  } catch (e) {
    if (e.name === "TimeoutError" || e.name === "AbortError") return res.status(504).json({ error: "Keystone took too long to answer. Try again." });
    res.status(e.status || 502).json({ error: e.message });
  }
});

module.exports = r;
